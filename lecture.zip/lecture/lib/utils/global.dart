//import 'package:flutterletterfirstapp/models/users.dart';

class Global{
  //static Users users;
  String title;
  String message;
  String showimage;
  Global(this.title, this.message, this.showimage);
}