import 'package:flutter/material.dart';
import 'package:marquee_flutter/marquee_flutter.dart';
import 'package:shimmer/shimmer.dart';

class Flash extends StatefulWidget {
  @override
  _FlashState createState() => _FlashState();
}

class _FlashState extends State<Flash> {
  changePage() async {
    await Future.delayed(Duration(seconds: 5));
    Navigator.pushNamed(context, "/login");
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    changePage();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Flash Screen"),
      ),
      body:Column(
        children: [
          Expanded(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Shimmer.fromColors(
                      child: Text('Shop Me',style: TextStyle(fontSize: 45,color: Colors.blue,fontFamily: "google",fontStyle: FontStyle.italic),),
                      baseColor: Colors.redAccent,
                      highlightColor: Colors.lightBlue,
                  ),
                  SizedBox(height: 45,),
                  Image(image: AssetImage("assets/coder.jpg")),
                  SizedBox(height: 45,),
                  CircularProgressIndicator(),
                ],
              ),
            ),
          ),
          Container(
            height: 30,
            color: Colors.lightBlue,
            child: MarqueeWidget(
              text: "Now with can display a Marquee effect on each and every widget, as other marquee widgets can support only text, with this widget you can marquee any available widget.",
            ),
          ),
        ],
      )
    );
  }
}
