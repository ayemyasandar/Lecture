import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutterletterfirstapp/models/users.dart';
import 'package:flutterletterfirstapp/utils/global.dart';
import 'package:http/http.dart' as http;
class ListSample extends StatefulWidget {
  @override
  _ListSampleState createState() => _ListSampleState();
}

class _ListSampleState extends State<ListSample> {
  final String link ="https://randomuser.me/api/?results=100";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List Sample Screen"),
      ),
      body: FutureBuilder(
          future: getUsers(),
          builder: (context, projectSnap) {
            if(projectSnap.hasData) {
              return ListView.builder(
                  itemCount: projectSnap.data.length,
                  itemBuilder: (context,ind) {
                    return ListTile(
                      onTap: (){
                        Navigator.pushNamed(
                            context, "/userDetail",arguments:Global(projectSnap.data[ind].name, projectSnap.data[ind].email,projectSnap.data[ind].picture)
                            );
                      },
                      // ignore: missing_return
                      leading: Image(image: NetworkImage(projectSnap.data[ind].picture)),
                      title: Text(projectSnap.data[ind].name),
                      subtitle: Text(projectSnap.data[ind].email),
                    );
                  }
              );// ignore: missing_return
            }else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          },
      ),
    );
  }
  Future<List<Users>> getUsers() async {
    http.Response response =await http.get(link);
    List Lisy =jsonDecode(response.body)["results"] as List;
    List<Users> userList =Lisy.map((e) => Users.fromJson(e)).toList();
    return userList;
  }
}

