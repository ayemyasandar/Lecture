import 'package:flutter/material.dart';
import 'package:flutterletterfirstapp/utils/global.dart';

class UserDetail extends StatefulWidget {
  @override
  _UserDetailState createState() => _UserDetailState();
}

class _UserDetailState extends State<UserDetail> {
  @override
  Widget build(BuildContext context) {
    Global args =ModalRoute.of(context).settings.arguments;
    return Scaffold(
      appBar: AppBar(
        title: Text(args.title),
      ),
      body: Center(

        child: Column(
          children: [
            Text(args.message),
          ],
        ),
      ),
    );
  }
}

