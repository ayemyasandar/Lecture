import 'package:flutter/material.dart';
class GridSample extends StatefulWidget {
  @override
  _GridSampleState createState() => _GridSampleState();
}

class _GridSampleState extends State<GridSample> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Grid Sample Screen"),
      ),
    );
  }
}


