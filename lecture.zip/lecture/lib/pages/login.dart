import 'package:flutter/material.dart';
class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login Screen"),
      ),
      body: Container(
        padding: EdgeInsets.all(50),
        child: Column(
          children: [
            Text('Login To Verify',style: TextStyle(fontSize: 45,color: Colors.blue,fontWeight: FontWeight.bold),),
            SizedBox(height: 20,),
            TextFormField(
              decoration: InputDecoration(
                labelText: "Username",
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5)
                ),
              ),
            ),
            SizedBox(height: 20,),
            TextFormField(
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5)
                ),
              ),
            ),
            Row(
              children: [
                RaisedButton(
                  onPressed: (){
                    Navigator.pushNamed(context, "/register");
                  },
                  color: Colors.lightBlue,
                  child: Text("Register",style: TextStyle(color: Colors.white),),
                ),
                Spacer(),
                RaisedButton(
                  onPressed: (){
                    Navigator.pushNamed(context, "/listSample");
                  },
                  color: Colors.blue,
                  child: Text("Login",style: TextStyle(color: Colors.white),),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

