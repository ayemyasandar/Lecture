class Users{
  String name;
  String picture;
  String email;
  Users({
    this.name,
    this.email,
    this.picture
  });
  factory Users.fromJson(dynamic json) => Users(
    name: json["name"]["title"]+json["name"]["first"]+json["name"]["last"],
    email: json["email"],
    picture: json["picture"]["thumbnail"],
  );
}