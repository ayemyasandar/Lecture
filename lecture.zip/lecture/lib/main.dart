import 'package:flutter/material.dart';
import 'package:flutterletterfirstapp/pages/gridsample.dart';
import 'package:flutterletterfirstapp/pages/listsample.dart';
import 'package:flutterletterfirstapp/pages/login.dart';
import 'package:flutterletterfirstapp/pages/register.dart';
import 'package:flutterletterfirstapp/pages/userDetail.dart';

import 'pages/flash.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        "/":(context)=>Flash(),
        "/login":(context)=>Login(),
        "/register":(context)=>Register(),
        "/listSample":(context)=>ListSample(),
        "/userDetail":(context)=>UserDetail(),
        "/gridSample":(context)=>GridSample(),
      },
    );
  }
}

